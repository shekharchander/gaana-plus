chrome.webRequest.onBeforeRequest.addListener(
    function() {
        return {cancel: true};
    },
    {
        urls: ["*://pagead2.googlesyndication.com/*","*://*.doubleclick.net/*"]
    },
    ["blocking"] 
);
c = document.createElement('script');
c.innerHTML = "function selectBitrateIcon(){console.log('Stopping Quality Change')} function isGaanaPaidUserCheck(){console.log('Making User Paid');return !!1} function isGaanaPlusDownloadable(){console.log('Enabling Downloads');return !!1}";
b = document.getElementsByTagName('body')[0];
b.append(c);
setTimeout(function()
{	a = document.getElementsByClassName('addFee_btn')
	if(a !== null){a[0].remove();}
	else{setTimout(function(){a.remove();}),1000}
	document.getElementsByClassName('_upgrade')[0].remove(); 
	console.log('upgrade button removed');
},2000);